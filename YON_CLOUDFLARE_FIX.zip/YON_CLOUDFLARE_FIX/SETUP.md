# Yon Assistant — Cloudflare Pages

Perbaikan berdasarkan repo dionnsadboyy/portofolio pada commit 6c47d50a2e97650f5eeed5f92f52f9ab9dfeb856.

## Kondisi yang ditemukan

- Domain dionpratama.my.id sudah mengarah ke project Pages `portofolio`.
- Branch produksi `main`; build command `exit 0`; output `.`.
- Backend di `api/portfolio-assistant.js` masih berupa handler Node.js.
- Belum ada folder `functions/` untuk endpoint Cloudflare Pages.
- Konfigurasi dari `.env` lokal tidak otomatis menjadi environment production.

Patch ini sudah dibuat dan diuji, tetapi BELUM di-commit atau di-deploy karena koneksi browser terputus. Penyimpanan LLM_BASE_URL dan LLM_MODEL telah dikirim dari dashboard; tampilan setelah penyimpanan belum bisa diverifikasi. API key belum diisi.

## Terapkan di workspace VS Code

Ekstrak ZIP lalu salin `cloudflare-yon.patch` ke root repo portfolio. Jalankan:

```bash
git apply --check cloudflare-yon.patch
git apply cloudflare-yon.patch
node scripts/check.js
git add api/portfolio-assistant.js functions/api/portfolio-assistant.js README.md
git commit -m "Enable Yon Assistant on Cloudflare Pages"
git push origin main
```

Jika `git apply --check` menunjukkan konflik, hentikan penerapan otomatis dan minta Codex menyesuaikan perubahan pada versi terbaru. Jangan reset atau menimpa perubahan lokal. File patch tidak perlu di-commit.

## Konfigurasi Cloudflare

Buka Workers & Pages → portofolio → Settings → Variables and secrets. Pastikan environment `Production`.

| Variable | Type | Value |
| --- | --- | --- |
| LLM_BASE_URL | Text | https://api.koboillm.com/v1 |
| LLM_MODEL | Text | openai/gpt-4.1-mini |
| LLM_API_KEY | Secret | Nilai key yang sama dari `.env` lokal |

Gunakan Edit jika nama variabel sudah ada. Simpan sebelum push agar deployment terbaru mengambil konfigurasi. Jika sudah ter-deploy, gunakan Deployments → deployment main terbaru → Retry deployment, lalu tunggu status sukses.

Jangan upload `.env` ke repo. Key tetap di environment server. Tidak perlu Workers AI binding, Tunnel, atau perubahan DNS.

## Cek hasil

Buka https://dionpratama.my.id/api/portfolio-assistant. Respons yang diharapkan:

```json
{"success":true,"available":true}
```

Kemudian buka portfolio, buka Yon, tekan `Cek lagi` bila masih tampil, lalu kirim `hai, ceritakan proyek Dion`. Health check hanya memeriksa keberadaan konfigurasi; satu jawaban chat asli diperlukan untuk memastikan key dan provider bekerja. Jika tersedia tetapi chat gagal, periksa log Function tanpa membagikan key.

## Perubahan dan validasi

- Handler Node menerima environment opsional; perilaku localhost tetap sama.
- Adapter Pages meneruskan `context.env` per request tanpa mengubah environment global.
- Endpoint mempertahankan konteks dan prompt yang sama, validasi pesan/histori, timeout provider, batas body 32 KB termasuk stream, header metode, dan respons tanpa cache.
- README menjelaskan deployment Pages dan tiga variabel provider.
- Pemeriksaan project yang sudah ada lulus: build deterministik, 71 referensi lokal, metadata aset, sintaks, dan kontrak API.
- Tes adapter lulus untuk health check tanpa provider, environment terpisah antar-request, validasi, JSON rusak, payload berlebihan, metode tidak didukung, dan provider gagal.
- Wrangler 4.152.0 berhasil mengompilasi Functions menjadi Worker.
- Route health dari bundle Worker hasil kompilasi diuji.
- Tidak ada panggilan AI live atau biaya provider selama pengujian.
